import React, { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../SIDEBAR/Sidebar";
import "./Booktable.css";

function Booktable() {

const [bookings,setBookings] = useState([]);
const [search,setSearch] = useState("");
const [currentPage,setCurrentPage] = useState(1);

const rowsPerPage = 5;

useEffect(()=>{
fetchBookings();
},[]);

const fetchBookings = async()=>{

try{

const res = await axios.get("http://localhost:5000/api/booking/all");

setBookings(res.data);

}catch(error){

console.log("Error fetching bookings");

}

};

const updateStatus = async(id,newStatus)=>{

try{

await axios.put(`http://localhost:5000/api/booking/update/${id}`,{
status:newStatus
});

fetchBookings();

}catch(error){

console.log("Error updating status");

}

};


/* SEARCH */

const filteredBookings = bookings.filter((item)=>{

const service = Array.isArray(item.services)
? item.services.join(" ").toLowerCase()
: (item.services || "").toLowerCase();

const status = (item.status || "").toLowerCase();

const keyword = search.toLowerCase();

return service.includes(keyword) || status.includes(keyword);

});


/* RESET PAGE WHEN SEARCH */

useEffect(()=>{
setCurrentPage(1);
},[search]);


/* PAGINATION */

const indexOfLast = currentPage * rowsPerPage;
const indexOfFirst = indexOfLast - rowsPerPage;

const currentBookings = filteredBookings.slice(indexOfFirst,indexOfLast);

const totalPages = Math.ceil(filteredBookings.length / rowsPerPage);

const nextPage = ()=>{
if(currentPage < totalPages){
setCurrentPage(currentPage + 1);
}
};

const prevPage = ()=>{
if(currentPage > 1){
setCurrentPage(currentPage - 1);
}
};

return(

<div className="admin-container">

<Sidebar/>

<div className="admin-content">

<div className="topbar">
<h3>All Bookings</h3>
</div>

{/* SEARCH */}

<div className="search-box">

<input
type="text"
placeholder="Search service or status..."
value={search}
onChange={(e)=>setSearch(e.target.value)}
/>

</div>


{/* TABLE */}

<div className="table-container">

<table>

<thead>

<tr>
<th>#</th>
<th>Name</th>
<th>Service</th>
<th>Date</th>
<th>Phone</th>
<th>Status</th>
<th>Action</th>
</tr>

</thead>

<tbody>

{currentBookings.map((item,index)=>(

<tr key={item._id}>

<td>{indexOfFirst + index + 1}</td>

<td>{item.name}</td>

<td>
{Array.isArray(item.services)
? item.services.join(", ")
: item.services}
</td>

<td>{new Date(item.date).toLocaleDateString()}</td>

<td>{item.phone}</td>

<td>

<span className={`status ${item.status?.toLowerCase()}`}>
{item.status || "Pending"}
</span>

</td>

<td>

<button
className="approve-btn"
disabled={item.status !== "Pending"}
onClick={()=>updateStatus(item._id,"Approved")}
>
Approve
</button>

<button
className="reject-btn"
disabled={item.status !== "Pending"}
onClick={()=>updateStatus(item._id,"Rejected")}
>
Reject
</button>

</td>

</tr>

))}

</tbody>

</table>

</div>


{/* PAGINATION */}

<div className="pagination">

<button
onClick={prevPage}
disabled={currentPage === 1}
>
Prev
</button>

<span>
Page {currentPage} of {totalPages || 1}
</span>

<button
onClick={nextPage}
disabled={currentPage === totalPages}
>
Next
</button>

</div>

</div>

</div>

);

}

export default Booktable;