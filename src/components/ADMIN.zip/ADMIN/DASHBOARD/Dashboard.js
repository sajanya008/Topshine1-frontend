import React from "react";
import "./Dashboard.css";
import {  FaHome, 
  FaBoxOpen, 
  FaConciergeBell, 
  FaLayerGroup, 
  FaUserTie, 
  FaImages, 
  FaCog  } from "react-icons/fa";
import { NavLink } from "react-router-dom";

function Dashboard() {
  return (
    <div className="dashboard">
      
      {/* Sidebar */}
      <div className="sidebar">
        
        <h2 className="logo">Topshine</h2>
        <ul>
        <ul>
  <li><FaHome /> Dashboard</li>
  <li> <NavLink to="/admin/bookings"><FaBoxOpen /> Booking</NavLink></li>
  <li><NavLink to="/admin/services"><FaConciergeBell /> Services</NavLink></li>
  <li><NavLink to="/admin/packages/table"><FaLayerGroup />Packages</NavLink></li>
  {/* <li><FaLayerGroup /> Packages</li> */}
  <li><NavLink to="/admin/experts/table"><FaUserTie /> Our Expert</NavLink></li>
  <li><NavLink to="/admin/recentworks/table"><FaImages /> Our Recent Works</NavLink></li>
  <li><FaCog /> Settings</li>
</ul>
        </ul>
      </div>

      {/* Main Content */}
      <div className="main">
      
  <div className="dashboard-header">
    <div>
      <h2 className="welcome-text">Welcome, Sujith 👋</h2>
      <p className="sub-text">Here’s what’s happening today.</p>
    </div>
    
  </div>
        
        <h2>Overview</h2>

        {/* Cards */}
        <div className="cards">
          <div className="card">
            <h4>Total Booking</h4>
            <p>20,500</p>
          </div>

          <div className="card">
            <h4>New Customers</h4>
            <p>21,800</p>
          </div>

          <div className="card">
            <h4>Revenue</h4>
            <p>$30,400</p>
          </div>

          <div className="card">
            <h4>Cancelled</h4>
            <p>14,800</p>
          </div>
        </div>

        {/* Recent Activity Section */}
        <div className="recent">
          <h3>Recent Activity</h3>
          <ul>
            <li>New booking created</li>
            <li>Customer registered</li>
            <li>Payment received</li>
            <li>Booking cancelled</li>
          </ul>
        </div>

      </div>
    </div>
  );
}

export default Dashboard;