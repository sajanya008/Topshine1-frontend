import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  FaHome,
  FaBoxOpen,
  FaConciergeBell,
  FaLayerGroup,
  FaUserTie,
  FaImages,
  FaCog,
  FaBars,
  FaSignOutAlt
} from "react-icons/fa";

import "./Sidebar.css";

function Sidebar() {

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleLogout = () => {

    localStorage.removeItem("adminToken");

    navigate("/admin/login", { replace: true });

    window.location.reload(); // prevent back navigation
  };

  return (
    <>

      <FaBars
        className={`menu-icon ${sidebarOpen ? "move" : ""}`}
        onClick={toggleSidebar}
      />

      <div className={`sidebar ${sidebarOpen ? "active" : ""}`}>

        <h2 className="logo">Topshine</h2>

        <ul>

          <li>
            <NavLink to="/admin/dashboard">
              <FaHome /> Dashboard
            </NavLink>
          </li>

          <li>
            <NavLink to="/admin/bookings">
              <FaBoxOpen /> Booking
            </NavLink>
          </li>

          <li>
            <NavLink to="/admin/services">
              <FaConciergeBell /> Services
            </NavLink>
          </li>

          <li>
            <NavLink to="/admin/packages/table">
              <FaLayerGroup /> Packages
            </NavLink>
          </li>

          <li>
            <NavLink to="/admin/experts/table">
              <FaUserTie /> Our Experts
            </NavLink>
          </li>

          <li>
            <NavLink to="/admin/recentworks/table">
              <FaImages /> Recent Works
            </NavLink>
          </li>

          <li>
            <NavLink to="/admin/settings">
              <FaCog /> Settings
            </NavLink>
          </li>

        </ul>

        <div className="logout-btn" onClick={handleLogout}>
          <FaSignOutAlt /> Logout
        </div>

      </div>

    </>
  );
}

export default Sidebar;